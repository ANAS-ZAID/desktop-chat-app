﻿using ChatUser.core.tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatUser.core.classes
{
    static internal class ValidatingData
    {
        static public void Type(this AppTextBox control, TextBoxType type)
        {
            switch (type) { 
            
            case TextBoxType.Number:
                    control.NumberOnly();
                    break;
                case TextBoxType.Phone:
                    control.PhoneOnly();
                    break;
                case TextBoxType.Text:
                    control.TextOnly();
                    break;

                default:
                  
                    break;
            }
        }
        static public void NumberOnly(this AppTextBox control)
        {
            control.KeyPress += Control_KeyPress;
         
            void Control_KeyPress(object sender, KeyPressEventArgs e)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                    e.Handled = true;
            }

        }
        static public void PhoneOnly(this AppTextBox control)
        {
            control.KeyPress += Control_KeyPress;
           
            void Control_KeyPress(object sender, KeyPressEventArgs e)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                    e.Handled = true;
            }
            KeyPressEventHandler eventArgs = Control_KeyPress;
          
        }
        static public void TextOnly(this AppTextBox control)
        {
            control.KeyPress += Control_KeyPress;
           
            void Control_KeyPress(object sender, KeyPressEventArgs e)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Space)
                    e.Handled = true;
            }
        }
    }
    enum TextBoxType
    {
        Text,
        Phone,
        Number,
        Password

    }
}
