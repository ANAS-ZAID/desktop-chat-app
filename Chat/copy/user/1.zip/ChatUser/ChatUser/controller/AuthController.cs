﻿using ChatUser.data.local;
using ChatUser.data.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace ChatUser.controller
{
    internal class AuthController:Controller
    {
        DbContext db;
        public  bool isSinIn { get; set; }=true;
        public  bool isSinUp { get { return !isSinIn; } }
        Users user {  get; set; }

        public AuthController() { db = new DbContext();

            Users user =new Users() { phone=2,name="hamood", password = "hamood" };
            db.Users.insert(user);
        }
       public void changeAuth()
        {
            isSinIn = !isSinIn;
        }
         public void processing(string phone, string password, string name,string information,string img)
        { 
      

        }
        void signIn()
        {

        }
    }
}
