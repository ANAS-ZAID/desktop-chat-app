﻿using ChatUser.data.local;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatUser.controller
{
    internal class Controller
    {
      
      public  Controller()
        {
         
        }
         public void add()
        {

        }
        public void update()
        {

        }
        public void delete()
        {

        }
        public void select()
        {

        }



    }
}
