﻿using ChatUser.controller;
using ChatUser.core.classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatUser.view.screen
{
    public partial class SignIn : Form
    {
        AuthController controller;
        public SignIn()
        {
            InitializeComponent();
            controller = new AuthController();
         phone.type =  TextBoxType.Phone;
         name.type =  TextBoxType.Text;
         elesName.type =  TextBoxType.Text;
        password.type = TextBoxType.Password;   
            showOrHideSinUp();
           
        }
        void showOrHideSinUp()
        {
            phone.Select();
            panelSinUp.Visible = controller.isSinUp;
            if (controller.isSinIn)
            {
                titel.Text = "تسجيل الدخول";
                submit.Top = panelSinUp.Top + 10;
                submit.Text = "تسجيل";
                changeAuth.Text = "هل تريد إنشاء حساب ؟";

            }
            else
            {
                titel.Text = "إنشاء حساب";
                submit.Top = panelSinUp.Top + panelSinUp.Height + 10;
                submit.Text = "إنشاء";
                changeAuth.Text = "هل تريد تسجيل الدخول ؟";

            }
        }

        private void submit_Click(object sender, EventArgs e)
        {

        }

        private void changeAuth_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            controller.changeAuth();
            showOrHideSinUp();
        }

       
    }
}
