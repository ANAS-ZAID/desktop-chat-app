﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatUser.data.model
{
    internal class Group:EntityWithImg
    {
        override public Dictionary<string, Object> json
        {
            get
            {
                return new Dictionary<string, Object>()
                {

                    {
                        "id",
                        id
                    },
                   
                    {
                        "name",
                        name
                    },
                   
                    
                    {
                        "img",
                        img
                    },
                   
                };
            }
        }

    }
}
