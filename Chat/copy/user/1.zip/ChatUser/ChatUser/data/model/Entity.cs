﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ChatUser.data.model
{
    internal class Entity
    {
     public   int id {  get; set; }
        public string name { get; set; }
   virtual  public Dictionary<string, Object> json
    {
        get;
    }
    }

    internal class EntityWithImg:Entity
    {
        public string img { get; set; }
    }
}
