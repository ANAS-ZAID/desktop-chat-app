﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatUser.data.model
{
    internal class Users: EntityWithImg
    {
        public int phone {  get; set; }
        public string password {  get; set; }
        public string elesName { get; set; }
        public string information { get; set; }
        
        public bool permission {  get; set; }
        
        public Users() { }
      override  public Dictionary<string, Object> json
        {
            get
            {
                return new Dictionary<string, Object>()
                {
                    
                    {
                        "phone",
                        phone
                    },
                    {
                        "password",
                        password
                    },
                    {
                        "name",
                        name
                    },
                    {
                        "elesName",
                        elesName
                    },
                    {
                        "information",
                        information
                    },
                    {
                        "img",
                        img
                    },
                    {
                        "permission",permission
                    },
                };
            }
        }
    }
}
