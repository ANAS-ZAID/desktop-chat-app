﻿using ChatUser.data.model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatUser.data.local
{
   
        internal class DataSet<T> : Entity where T : class
        {
            SqlQueryBuilder sqlQuery;

            SqlConnection conn;
            SqlCommand cmd;
            string table;
            public DataSet()
            {
                table = typeof(T).Name;
                sqlQuery = new SqlQueryBuilder(table);
                conn = DatabaseConnection.GetConnection();
                cmd = new SqlCommand() { Connection = conn, };
            }
            public int insert(T o)
            {
                Entity entity = o as Entity;
                //MessageBox.Show(sqlQuery.BuildInsertQuery(entity.json));

                int result = -1;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText += sqlQuery.BuildInsertQuery(entity.json);
                try
                {
                    open();
                    result = cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    close();
                }
                return result;
            }

            void open()
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
            }
            void close()
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
        }
    
}
