﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace ChatUser.data.local
{
    internal class SqlQueryBuilder
    {
        
            SqlConnection conn;
            SqlCommand cmd;
            string table;
            public SqlQueryBuilder(string table)
            {
                conn = DatabaseConnection.GetConnection();
                this.table = table;
                cmd = new SqlCommand() { Connection = conn, CommandType = CommandType.StoredProcedure };
            }
            void open()
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
            }
            void close()
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
            public int add(Dictionary<string, object> data)
            {
                open();
                cmd.Parameters.Clear();
                List<SqlParameter> sp = new List<SqlParameter>();
                cmd.CommandText = "add" + table;
                foreach (var item in data)
                {
                    cmd.Parameters.AddWithValue("@" + item.Key, item.Value);
                }
                int id = Convert.ToInt32(cmd.ExecuteScalar());
                close();
                return id;

            }
            public DataTable GetDataTable()
            {
                DataTable dt = new DataTable();
                cmd.Parameters.Clear();
                cmd.CommandText = "GetTableData";

                cmd.Parameters.AddWithValue("@TableName", table + "s");
                open();
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                close();
                return dt;
            }
            public int Delete(int id)
            {
                open(); cmd.Parameters.Clear();
                cmd.CommandText = "DeleteRowFromTable";
                cmd.Parameters.AddWithValue("@TableName", table + "s");
                cmd.Parameters.AddWithValue("@id", id);
                close();
                return Convert.ToInt32(cmd.ExecuteScalar());

            }
            public DataRow GetRow(int id)
            {
                DataTable dt = new DataTable();
                open(); cmd.Parameters.Clear();
                cmd.CommandText = "GetRowDataFromTable";
                cmd.Parameters.AddWithValue("@TableName", table + "s");
                cmd.Parameters.AddWithValue("@id", id);
                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                close();
                return dt.Rows[0];
            }

            public int insert(object o)
            {

                string table = o.GetType().Name;
                string values = "";
                string fields = "";
            //foreach (var item in parameters)
            //{
            //    fields += item.ParameterName + ",";
            //    values += (("'" + item.Value + "'")) + ",";
            //}
            foreach (var property in o.GetType().GetProperties())
                {
                    if (property.Name != "id")
                    {
                        fields += property.Name + ",";
                        values += (("'" + property.GetValue(o) + "'")) + ",";
                    }

                }
                fields = fields.Remove(fields.Length - 1);
                values = values.Remove(values.Length - 1);
                string sql = "insert into " + table + "(" + fields + ") values(" + values + ")";
                cmd.CommandType = CommandType.Text;
                cmd.CommandText += sql;
                open();
                int r = cmd.ExecuteNonQuery();
                close();
                return r;
            }
        public string BuildInsertQuery(Dictionary<string, object> data)
        {
           
           dynamic columnWithData= getColumnWithData(data);
            string sql = "INSERT INTO " + table + "(" + columnWithData.fields + ") values(" + columnWithData. values + ")";
            MessageBox.Show(sql.ToString());
            return sql.ToString();
        }
         dynamic getColumnWithData(Dictionary<string, object> data)
        {
            string values = "";
            string fields = "";
            foreach (var item in data)
            {
                fields += item.Key + ",";
                values += (item.Value is int?  item.Value :("'" + item.Value + "'")) + ",";
            }
            fields = fields.Remove(fields.Length - 1);
            values = values.Remove(values.Length - 1);
            return new  { fields=fields ,  values= values } ;
        }

    }
}
